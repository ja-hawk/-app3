// app/[username]/page.tsx
import { notFound } from "next/navigation";
import PersonaCard, { PersonaProps } from "@/components/PersonaCard";
import { getPersona } from "@/lib/data";

export default async function UserPage({
  params,
}: {
  params: Promise<{ username?: string }>; // ← Promise 型！
}) {
  // ここで await！
  const { username: rawUsername = "" } = await params;

  // @ を除去
  const username = rawUsername.replace(/^@/, "");

  if (!username) {
    return notFound();
  }

  const data: PersonaProps | null = await getPersona(username);
  if (!data) return notFound();

  return <PersonaCard {...data} />;
}