import "./globals.css";
import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Tweet Persona",
  description: "AIがあなたのX人物像を診断",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="ja">
      <body>{children}</body>
    </html>
  );
}