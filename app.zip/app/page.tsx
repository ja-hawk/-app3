"use client";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Home() {
  const router = useRouter();

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const input = e.currentTarget.elements.namedItem("username") as HTMLInputElement;
    const username = input.value.trim().replace(/^@/, ""); // @ を除去
    if (!username) return;

    // @ を必ず付ける！
    router.push(`/@${username}`);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <h1 className="text-4xl font-bold text-center mb-8 text-indigo-800">
          Tweet Persona
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Xのユーザー名を入れて、AIが人物像を診断！
        </p>
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            name="username"
            type="text"
            placeholder="@username"
            className="flex-1 px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition"
            defaultValue="joshtriedcoding"
          />
          <button
            type="submit"
            className="px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition"
          >
            診断
          </button>
        </form>
        <p className="text-center mt-8 text-sm text-gray-500">
          例: <Link href="/@joshtriedcoding" className="text-indigo-600 hover:underline">@joshtriedcoding</Link>
        </p>
      </div>
    </div>
  );
}