export type PersonaProps = {
  name: string;
  handle: string;
  bio: string;
  location: string;
  role: string;
  tags: string[];
  humor: number;
  networking: number;
  tech: number;
  similar: string[];
  quote: string;
};

export default function PersonaCard({
  name,
  handle,
  bio,
  location,
  role,
  tags,
  humor,
  networking,
  tech,
  similar,
  quote,
}: PersonaProps) {
  return (
    <div className="bg-white rounded-xl shadow-xl p-6 max-w-lg mx-auto">
      <div className="flex items-center gap-4 mb-6">
        <div className="w-16 h-16 bg-gray-300 rounded-full flex items-center justify-center text-2xl font-bold">
          {name[0]}
        </div>
        <div>
          <h2 className="text-2xl font-bold">{name}</h2>
          <p className="text-lg text-gray-600">@{handle}</p>
        </div>
      </div>

      <p className="text-sm text-gray-700 mb-2">{bio}</p>
      <p className="text-xs text-gray-500 mb-4">
        📍 {location} | {role}
      </p>

      <div className="flex flex-wrap gap-2 mb-6">
        {tags.map((tag) => (
          <span
            key={tag}
            className="px-3 py-1 bg-indigo-100 text-indigo-700 rounded-full text-xs"
          >
            {tag}
          </span>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-4 text-center mb-6">
        <div>
          <p className="text-2xl font-bold text-purple-600">{humor}%</p>
          <p className="text-xs text-gray-600">ユーモア</p>
        </div>
        <div>
          <p className="text-2xl font-bold text-blue-600">{networking}%</p>
          <p className="text-xs text-gray-600">人脈力</p>
        </div>
        <div>
          <p className="text-2xl font-bold text-green-600">{tech}%</p>
          <p className="text-xs text-gray-600">技術力</p>
        </div>
      </div>

      <div className="mb-4">
        <p className="text-sm font-semibold">似てる人:</p>
        <p className="text-sm text-gray-600">{similar.join(", ")}</p>
      </div>

      <blockquote className="border-l-4 border-indigo-500 pl-4 italic text-gray-700">
        "{quote}"
      </blockquote>
    </div>
  );
}
