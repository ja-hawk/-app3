import React from "react";

type AvatarProps = {
  className?: string;
  src?: string;
  fallback?: React.ReactNode;
};

export function Avatar({ className = "", src, fallback }: AvatarProps) {
  return (
    <div className={`rounded-full overflow-hidden bg-gray-300 flex items-center justify-center ${className}`}>
      {src ? <img src={src} alt="avatar" className="w-full h-full object-cover" /> : fallback}
    </div>
  );
}

export function AvatarFallback({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}

export function AvatarImage({ src, alt }: { src: string; alt: string }) {
  return <img src={src} alt={alt} className="w-full h-full object-cover" />;
}
