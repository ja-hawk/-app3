// lib/data.ts
import { TwitterApi } from "twitter-api-v2";
import { PersonaProps } from "@/components/PersonaCard";

const client = new TwitterApi(process.env.X_BEARER_TOKEN || ""); // .env に X_BEARER_TOKEN=your_token

export async function getPersona(username: string): Promise<PersonaProps | null> {
  try {
    // 1. ユーザー情報取得
    const user = await client.v2.userByUsername(username);
    if (!user.data) return null;

    // 2. 最新20件のツイート取得
    const tweets = await client.v2.userTimeline(user.data.id, {
      max_results: 20,
      "tweet.fields": ["created_at", "public_metrics", "author_id"],
    });

    // 3. ツイートテキストをまとめて AI に送る（ここでは OpenAI/Grok API 想定）
    const tweetText = tweets.data.map((t) => t.text).join("\n\n");
    const bio = user.data.description || "";

    // 4. AI で分析（例: OpenAI GPT-4o-mini を使う場合）
    // const prompt = `Analyze this user's X profile and tweets. Create a fun persona diagnosis.\nBio: ${bio}\nTweets: ${tweetText}\nOutput: {persona: "...", description: "...", emoji: "..."}`;
    // const aiResponse = await openai.chat.completions.create({ ... }); // 実装省略
    // return JSON.parse(aiResponse.choices[0].message.content || "{}") as PersonaProps;

    // デモ用: モックを本物風に（実際は AI レスポンス）
    return {
      username,
      persona: "ユーモラスな DevRel マエストロ",
      description: "React と Upstash を愛する陽キャエンジニア。ツイートはユーモア満載でコミュニティを熱くする！",
      emoji: "🐐😭",
    };
  } catch (error) {
    console.error("X API Error:", error);
    return null;
  }
}