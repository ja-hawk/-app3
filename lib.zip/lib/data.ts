export type Persona = {
  name: string;
  handle: string;
  bio: string;
  location: string;
  role: string;
  tags: string[];
  humor: number;
  networking: number;
  tech: number;
  similar: string[];
  quote: string;
};

const personas: Record<string, Persona> = {
  joshtriedcoding: {
    name: "Josh Tried Coding",
    handle: "joshtriedcoding",
    bio: "React界の陽気なDevRelリーダー。SFで人脈無双。サーバーレスとユーモアを愛する。",
    location: "San Francisco",
    role: "Lead DevRel @ Upstash",
    tags: ["React", "Next.js", "Serverless", "TypeScript", "nuqs", "Contentport"],
    humor: 92,
    networking: 98,
    tech: 95,
    similar: ["@leeerob", "@rauchg", "@convex_dev"],
    quote: "well hell yeah then you’re invited very cool people there",
  },
  johndoe: {
    name: "John Doe",
    handle: "johndoe",
    bio: "TypeScriptと猫を愛するフルスタックエンジニア。",
    location: "Tokyo",
    role: "Software Engineer",
    tags: ["TypeScript", "Next.js", "React", "Node.js"],
    humor: 75,
    networking: 65,
    tech: 88,
    similar: ["@midudev", "@shadcn", "@thekitze"],
    quote: "コードは詩であり、型はリズムだ。",
  },
};

export function getPersona(username: string): Persona | null {
  const key = username.replace(/^@/, "").toLowerCase();
  return personas[key] ?? null;
}
